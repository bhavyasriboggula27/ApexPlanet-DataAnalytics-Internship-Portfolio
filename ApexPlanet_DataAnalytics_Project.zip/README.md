
# ApexPlanet Data Analytics Internship Portfolio

## Project Overview
End-to-end sales analytics project using Python, Pandas, SQL and BI concepts.

## Completed Tasks
- Data Cleaning and Wrangling
- Exploratory Data Analysis
- KPI Development
- Business Insights
- Final Presentation

## Tools
Python | Pandas | SQL | Excel | Power BI concepts
