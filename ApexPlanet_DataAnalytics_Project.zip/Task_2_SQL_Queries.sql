
-- Top 5 products by revenue
SELECT Product, SUM(Total_Sales) AS Revenue
FROM Sales
GROUP BY Product
ORDER BY Revenue DESC LIMIT 5;

-- Monthly sales trend
SELECT MONTH(Order_Date), SUM(Total_Sales)
FROM Sales
GROUP BY MONTH(Order_Date);

-- Category performance
SELECT Category, SUM(Total_Sales)
FROM Sales
GROUP BY Category;
